# 1. Requirements
Please be sure you have installed __*node*__, __*typescript*__ and __*typings*__ globally.
# 2. How To Use
Take the *tsconfigurer_shipping* folder to the folder of your new __TypeScript__ Project and then execute

>```tsconfigurer.cmd ```

It will create all the stuff you need for common typescript projects startup.
After that you can open the project in your favourite editor or just run *openMe.cmd* that will try to open it in *vscode* (also this require vscode being on global path).

# 3. Customize
With the stuff you need already created you can customize your settings however you prefer. Just tweek in the places you like and that's all.

# 4. Use it!
This code is purely by me (Roberto Mapelli). You can Freely download it and modify it. However if you like this and want to give me a hand in improving this i'll be happy. 

> At the moment being on PATH variable is not supported at all